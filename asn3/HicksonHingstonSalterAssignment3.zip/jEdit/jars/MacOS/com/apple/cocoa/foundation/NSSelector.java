package com.apple.cocoa.foundation;

public class NSSelector {
	public NSSelector(String s, Class[] ca) { }
}
