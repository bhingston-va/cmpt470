package com.apple.cocoa.foundation;

public class NSMutableDictionary extends NSDictionary
{
}
