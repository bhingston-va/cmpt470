package com.apple.eawt;

public class ApplicationAdapter implements ApplicationListener {
}
