package com.apple.eio;

import java.io.IOException;

public class FileManager {
	public static void setFileTypeAndCreator(String s, int i1, int i2) throws IOException { }
	public static int getFileType(String s) throws IOException { return 0; }
	public static int getFileCreator(String s) throws IOException { return 0; }
}
